var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var UserSchema = new Schema({
  // accessToken : String,
  // email: String,
  // id: String,
  // name: String,
  // picture: {
  //   data: {
  //     is_silhouette: String,
  //     url:String
  //   }
  // },
  // signedRequest: String,
  userID: String,
  savedRides: [String]
});

module.exports = mongoose.model('User', UserSchema);
