var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var RideSchema = new Schema({
  userID: String,
  // userID: Schema.ObjectId,
  // name: String,
  rideTo: String,
  rideFrom: String,
  date: Date,
  cost: String,
  about: String,
  posted: Boolean
});

module.exports = mongoose.model('Ride', RideSchema);
