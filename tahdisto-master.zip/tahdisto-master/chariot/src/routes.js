/*jshint esversion: 6 */
import React from 'react';
import {Router, Route, browserHistory, IndexRoute} from 'react-router';
import App from './App';
import Landing from './components/landing/Landing';
import Home from './components/Home';
import Riding from './components/riding/Riding';
import Driving from './components/driving/Driving';
import Results from './components/Results';
import Filter from './components/Filter'
import MyRides from './components/MyRides';


export default (
  <Router history={browserHistory}>
    <Route path='/' component={App}>
      // <IndexRoute component={Landing} />
      <IndexRoute component={Home} />
      // <Route path='home' component={Home} />
      <Route path='riding' component={Riding} />
      <Route path='driving' component={Driving} />
      <Route path='results' component={Results} />
      <Route path='results/filter' component={Filter} />
      <Route path='myrides' component={MyRides} />
    </Route>
  </Router>
);
