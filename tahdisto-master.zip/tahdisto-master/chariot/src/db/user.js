var mongoose = require('mongoose');
var Schema = mongoose.Schema;

// var UserSchema = new Schema({
//   accessToken : String,
//   email: String,
//   id: Number,
//   name: String,
//   picture: {
//     data: {
//       is_silhouette: Boolean,
//       url:String
//     }
//   },
//   signedRequest: String,
//   userID: Number
// });

var UserSchema = new Schema({
  name: String
});

module.exports = mongoose.model('User', UserSchema);
