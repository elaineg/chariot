/*jshint esversion: 6 */
// Users
function users(callback) {
  return fetch(`api/users`, {
    accept: 'application/json',
  }).then(checkStatus)
    .then(parseJSON)
    .then(callback);
}
function find_user(user_id, callback) {
  return fetch(`api/users/${user_id}`, {
    accept: 'application/json'
  }).then(checkStatus)
    .then(parseJSON)
    .then(callback);
}
function add_user(user, callback) {
  return fetch(`api/users/`, {
    method: 'post',
    body: JSON.stringify( user ) ,
    headers: {
      'Content-Type': 'application/json'
    }

  }).then(checkStatus)
    .then(parseJSON)
    .then(callback);
}

function add_saved(user_id, saved_id, callback) {
  return fetch(`api/user-save/${user_id}/${saved_id}`, {
    method: 'put',
    accept: 'application/json'
  }).then(checkStatus)
    .then(parseJSON)
    .then(callback);
}
function remove_saved(user_id, saved_id, callback) {
  return fetch(`api/user-save/${user_id}/${saved_id}`, {
    method: 'delete',
    accept: 'application/json'
  }).then(checkStatus)
    .then(parseJSON)
    .then(callback);
}

// Ride
function rides(callback) {
  return fetch(`api/rides`, {
    accept: 'application/json',
  }).then(checkStatus)
    .then(parseJSON)
    .then(callback);
}
function find_ride(id, callback) {
  return fetch(`api/rides/${id}`, {
    accept: 'application/json'
  }).then(checkStatus)
    .then(parseJSON)
    .then(callback);
}
function find_myRide(userID, callback) {
  return fetch(`api/rides-user/${userID}`, {
    accept: 'application/json'
  }).then(checkStatus)
    .then(parseJSON)
    .then(callback);
}
function find_rides(from, to, callback) {
  return fetch(`api/rides/${from}/${to}`, {
    accept: 'application/json'
  }).then(checkStatus)
    .then(parseJSON)
    .then(callback);
}
function add_ride(ride, callback) {
  return fetch(`api/rides/`, {
    method: 'post',
    body: JSON.stringify( ride ) ,
    headers: {
      'Content-Type': 'application/json'
    }
  }).then(checkStatus)
    .then(parseJSON)
    .then(callback);
}
function delete_ride(ride_id, callback) {
  return fetch(`api/rides-delete/${ride_id}`, {
    method: 'delete',
    accept: 'application/json'
  }).then(checkStatus)
    .then(parseJSON)
    .then(callback);
}

function checkStatus(response) {
  if (response.status >= 200 && response.status < 300) {
    return response;
  } else {
    const error = new Error(`HTTP Error ${response.statusText}`);
    error.status = response.statusText;
    error.response = response;
    console.log(error); // eslint-disable-line no-console
    throw error;
  }
}

function parseJSON(response) {
  return response.json();
}

const Client = { users, find_user, add_user, rides, find_ride, find_myRide, find_rides, add_ride, add_saved, remove_saved, delete_ride };
export default Client;
