import React, {Component} from 'react';
import FacebookActions from './components/actions/FacebookActions';
import FacebookStore from './components/stores/FacebookStore';
import Landing from './components/landing/Landing';
import Footer from './components/Footer';
import Header from './components/Header';
import './App.css';

class App extends Component {
    constructor(props) {
        super();
        FacebookActions.initFacebook();
        FacebookStore.addChangeListener(() => this._onFacebookChange());
        // this.state = this.getFacebookState();
        this.state = {
          loading: true,
          accessToken: FacebookStore.accessToken,
          loggedIn: FacebookStore.loggedIn,
          userId: FacebookStore.userId,
          user: FacebookStore.facebookUserInfo,
          facebookPictureStatus: FacebookStore.facebookPictureStatus,
          facebookPictureUrl: FacebookStore.facebookPictureUrl,
        }
    }

    getFacebookState() {
        return {
          accessToken: FacebookStore.accessToken,
          loggedIn: FacebookStore.loggedIn,
          userId: FacebookStore.userId,
          user: FacebookStore.facebookUserInfo,
          facebookPictureStatus: FacebookStore.facebookPictureStatus,
          facebookPictureUrl: FacebookStore.facebookPictureUrl,
        }
    }
    // componentWillMount() {
    //     FacebookActions.initFacebook();
    //     FacebookStore.addChangeListener(() => this._onFacebookChange());
    // }
    //
    componentDidMount() {
      setTimeout(() => this.setState({ loading: false }), 1000);
    }

    componentWillUnmount() {
        FacebookStore.removeChangeListener(this._onFacebookChange);
    }

    _onFacebookChange() {
        this.setState(this.getFacebookState());
    }

    render() {

        if (this.state.loading){
          // setup loading class, give time to check loginstatus before doing anything
          return null;
        } else {
          return (
              <div className="App">
                  {this.state.loggedIn ? <Header/> : null}
                  {!this.state.loggedIn ? <Landing /> :
                    React.cloneElement(this.props.children,
                      { user: this.state.user, accessToken: this.state.accessToken }
                    )}
                  <Footer />
              </div>
          );
      }
    }
}

export default App;
