/*jshint esversion: 6 */
import FacebookDispatcher from '../dispatcher/FacebookDispatcher';
import Constants from '../constants/Constants';
import Client from '../../Client';


const APP_ID = '147742362364512';

const FacebookActions = {
    initFacebook: function() {
        window.fbAsyncInit = function() {
                window.FB.init({
                    appId: APP_ID,
                    xfbml: true,
                    version: 'v2.5'
                });

                // after initialization, get the login status
                FacebookActions.getLoginStatus();
            },
            (function(d, s, id) {
                var js, fjs = d.getElementsByTagName(s)[0];
                if (d.getElementById(id)) return;
                js = d.createElement(s);
                js.id = id;
                js.src = "//connect.facebook.net/en_US/sdk.js#xfbml=1&version=v2.8&appId=147742362364512";
                fjs.parentNode.insertBefore(js, fjs);
            }(document, 'script', 'facebook-jssdk'));
    },

    getLoginStatus: function() {
        window.FB.getLoginStatus((response) => {
            // console.log(response);
            if(response.status === 'connected'){
              Client.find_user(response.authResponse.userID, (user) => {
                  if (user.length === 0) {
                      const newUser = {
                          savedRides: [],
                          userID: response.authResponse.userID
                      };
                      Client.add_user(newUser, (addedUser) => {
                          console.log(addedUser);
                      });
                  }
              });
              this.getUser(response.authResponse.userID);
            }
            FacebookDispatcher.dispatch({
                actionType: Constants.FACEBOOK_INITIALIZED,
                data: response
            });

        });
    },

    login: () => {
        window.FB.login((response) => {
            if (response.status === 'connected') {
                Client.find_user(response.authResponse.userID, (user) => {
                    if (user.length === 0) {
                        const newUser = {
                            savedRides: [],
                            userID: response.authResponse.userID
                        };
                        Client.add_user(newUser, (addedUser) => {
                            console.log(addedUser);
                        });
                    }
                });
                FacebookDispatcher.dispatch({
                    actionType: Constants.FACEBOOK_LOGGED_IN,
                    data: response
                });
            }
        });
    },

    logout: () => {
        window.FB.logout((response) => {
            FacebookDispatcher.dispatch({
                actionType: Constants.FACEBOOK_LOGGED_OUT,
                data: response
            });
        });
    },
    getUser: (userId) => {
        window.FB.api(`/${userId}`, {
            fields: 'first_name,link,picture'
        }, (response) => {
            // console.log(response);
            FacebookDispatcher.dispatch({
                actionType: Constants.FACEBOOK_USER_INFO,
                data: response
            });
        });
    },

    getFacebookProfilePicture: (userId) => {
        FacebookDispatcher.dispatch({
            actionType: Constants.FACEBOOK_GETTING_PICTURE,
            data: null
        });

        window.FB.api(`/${userId}/picture?type=large`, (response) => {
            FacebookDispatcher.dispatch({
                actionType: Constants.FACEBOOK_RECEIVED_PICTURE,
                data: response
            });
        });
    }
};

module.exports = FacebookActions;
