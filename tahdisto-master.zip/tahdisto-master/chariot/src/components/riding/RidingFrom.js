/*jshint esversion: 6 */
import React, { Component } from 'react';
import './RidingFrom.css';

class RidingFrom extends Component {
  constructor(props) {
    super(props);
    this.state = {
      // from: '',
      showNext: false
    };
    this.handleSearchFromChange = this.handleSearchFromChange.bind(this);

  }

  handleSearchFromChange(e) {
    if(this.props.onChange){
      this.props.onChange(e);
    }
    // if (this.props.value === '') {
    //   this.setState({
    //     showNext: false
    //   });
    // } else {
    //   this.setState({
    //     showNext: true
    //   });
    // }
  }

  render() {
    return (
      <div className={`RidingFrom ${ this.props.classNames }`}>
        <h1 className="container RidingFrom-title">Where are you coming from?</h1>
        <div className="container RidingFrom-input">
          <input
              className='RidingFrom-input--input'
              type='text'
              value={this.props.value}
              onChange={this.handleSearchFromChange}
              onFocus={this.props.onFocus}
              autoFocus
          />
          {
            this.state.showNext ? (
              <button className="RidingFrom-next--button" onClick={this.props.onClick}>
                <i
                  className='fa fa-level-down'
                  // onClick={this.handleSearchCancel}
                />
              </button>
            ) : null
          }
        </div>
      </div>

    );
  }
}

export default RidingFrom;
