/*jshint esversion: 6 */
import React, { Component } from 'react';
import './RidingTo.css';

class RidingTo extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showSearchButton: true
    };
    this.handleSearchGoingChange = this.handleSearchGoingChange.bind(this);

  }

  handleSearchGoingChange(e) {
    if(this.props.onChange){
      this.props.onChange(e);
    }

    // if (this.props.value === '') {
    //   this.setState({
    //     showSearchButton: false
    //   });
    // } else {
    //   this.setState({
    //     showSearchButton: true
    //   });
    // }
  }

  render() {
    return (
      <div className={`RidingTo ${ this.props.classNames }`}>
        <h1 className="RidingTo-title">Where are you going?</h1>
          <div className="RidingFrom-input">
            <input
                className='RidingTo-input--input'
                type='text'
                value={this.props.value}
                onChange={this.handleSearchGoingChange}
                onFocus={this.props.onFocus}
            />
          </div>
        {
          this.state.showSearchButton ? (
            <button className="RidingTo-search--button"
              onClick={this.props.onClick}
              disabled={this.props.activeComponent !== 'RidingTo'}>
              SEARCH ALL RIDES
            </button>
          ) : null
        }
      </div>

    );
  }
}

export default RidingTo;
