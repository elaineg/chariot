/*jshint esversion: 6 */
import React, { Component, PropTypes } from 'react';
import './Riding.css';
import RidingFrom from './RidingFrom';
import RidingTo from './RidingTo';

const contextTypes = {
  router: PropTypes.object.isRequired
};

class Riding extends Component {
  constructor(props) {
    super(props);
    this.state = {
      ridingTo: '',
      ridingFrom: '',
      showRidingTo: true
    };
    this.handleFromChange = this.handleFromChange.bind(this);
    this.handleToChange = this.handleToChange.bind(this);
    this.handleNextClick = this.handleNextClick.bind(this);
    this.handleSubmitClick = this.handleSubmitClick.bind(this);
    this.handleFocus = this.handleFocus.bind(this);

  }

  handleFromChange(e){
    this.setState({
      ridingFrom: e.target.value
    });
  }

  handleToChange(e){
    this.setState({
      ridingTo: e.target.value
    });
  }

  handleNextClick() {
    this.setState({
      showRidingTo: true
    });
  }

  handleSubmitClick() {
    // console.log("submit");
    event.preventDefault();
    var ridingFrom = this.state.ridingFrom.toLowerCase();
    var ridingTo = this.state.ridingTo.toLowerCase();
    this.context.router.push({
      pathname: '/results',
      query: {
        from: ridingFrom.trim(),
        to: ridingTo.trim()
      }
    });
  }

  handleFocus(e) {
    this.setState({
      activeComponent: e.target.className.replace('-input--input', '')
    });
  }

  render() {
    return (
      <div className="Riding">
        <div className="Riding-input">
          <RidingFrom
            onClick={this.handleNextClick}
            value={this.state.ridingFrom}
            onChange={this.handleFromChange}
            onFocus={this.handleFocus}
            classNames={this.state.activeComponent === 'RidingFrom' ? 'active input' : 'inactive input'}
          />
        </div>
        <div className={"Riding-input " + (this.state.showRidingTo ? '' : 'Riding-hiddenDiv')}>
          <RidingTo
            onClick={this.handleSubmitClick}
            value={this.state.ridingTo}
            onChange={this.handleToChange}
            onFocus={this.handleFocus}
            classNames={this.state.activeComponent === 'RidingTo' ? 'active input' : 'inactive input'}
            activeComponent={this.state.activeComponent}
          />
        </div>
      </div>

    );
  }
}

Riding.contextTypes = contextTypes;

export default Riding;
