/*jshint esversion: 6 */
import React, { Component } from 'react';
import Client from '../Client';
import Card from './Card';
import FacebookStore from './stores/FacebookStore';
import './MyRides.css';


class MyRides extends Component {
  constructor(props) {
    super(props);
    this.state = {
      ridesPosted: [],
      ridesSaved: [],
      savedRideIds: [],
      ridesDelete: []
    };
    this.handleDeleteRide = this.handleDeleteRide.bind(this);
    this.handleSaveDelete = this.handleSaveDelete.bind(this);
    this.initRides = this.initRides.bind(this);
    this.initSaved = this.initSaved.bind(this);
    this.updateSaved = this.updateSaved.bind(this);
    // this.initRides();
    this.initSaved();
  }

  initRides() {
    Client.find_myRide(this.props.user.id, (ridesList) => {
      var posted = [];
      var notPosted = [];
      ridesList.map(function(ride){
        if(ride.posted){
          posted.push(ride);
        } else {
          notPosted.push(ride);
        }
      });
      if(posted > 1) {
        posted.sort(function(a,b) {
          return new Date(a.date) - new Date(b.date);
        });
      }
      this.setState({
        ridesPosted: posted,
        ridesDelete: notPosted
      });
    });

  }

  initSaved() {
    Client.find_user(FacebookStore.userId, (user) => {
      var userSavedRides = user[0].savedRides;

      this.setState({
        savedRideIds: userSavedRides
      });
      // this.initRides();
      this.updateSaved();
    });
  }

  updateSaved(){
    var savedRides = [];
    var savedIds = this.state.savedRideIds;
    var length = savedIds.length;
    var i = 0;
    if(length > 0){
      savedIds.map(function(ride){
        Client.find_ride(ride, (saved) => {
          savedRides.push(saved[0]);
          i++;
        });
      });
    }
    this.setState({
      ridesSaved: savedRides
    });
    this.initRides();


  }

  handleDeleteRide(id) {
    var rides = this.state.ridesPosted;
    rides.find(function(ride, index){
      if (ride._id === id){
        Client.delete_ride(id, (response) => {
            console.log(response);
        });
        delete rides[index];
      }
    })

    this.setState({rides: rides});

  }

  handleSaveDelete(id){
    var rides = this.state.ridesSaved;
    rides.find(function(ride, index){
      if(ride._id === id){
          Client.remove_saved(FacebookStore.userId, ride._id, (response) => {
            console.log(response);
          });
          delete rides[index];
      }
    });

    this.setState({
      ridesSaved: rides
    });
  }



  render() {
    const ridesPosted = this.state.ridesPosted.map((ride) => {
      return <Card key={ride._id}
                   id={ride._id}
                   rideTo={ride.rideTo}
                   rideFrom={ride.rideFrom}
                   date={ride.date}
                   cost={ride.cost}
                   about={ride.about}
                   userID={ride.userID}
                   button="Delete"
                   handleDeleteRide={this.handleDeleteRide}
                   posted={ride.posted} />
    });
    const ridesSaved = this.state.ridesSaved.map((ride) => {
      return <Card key={ride._id}
                   id={ride._id}
                   rideTo={ride.rideTo}
                   rideFrom={ride.rideFrom}
                   date={ride.date}
                   cost={ride.cost}
                   about={ride.about}
                   userID={ride.userID}
                   button="Message"
                   saved={true}
                   handleSaveDelete={this.handleSaveDelete}
                   posted={ride.posted} />
    });
    const ridesDelete = this.state.ridesDelete.map((ride) => {
      return <Card key={ride._id}
                   id={ride._id}
                   rideTo={ride.rideTo}
                   rideFrom={ride.rideFrom}
                   date={ride.date}
                   cost={ride.cost}
                   userID={ride.userID}
                   about={ride.about}
                   button=""
                 />
    });
    return (
      <div className="MyRides-container">
        <h2 className="MyRides-title">My Rides</h2>
          {ridesPosted}
        <br/>
        <h2 className="MyRides-title">Saved Rides</h2>
          {ridesSaved}
        <br/>
        <h2 className="MyRides-title">Old Rides</h2>
          {ridesDelete}
        <br/>
      </div>
    )
  }
}



export default MyRides;
