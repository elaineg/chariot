import React, { Component, PropTypes } from 'react';
import './Filter.css';
import DrivingDate from './driving/DrivingDate';
import DrivingCost from './driving/DrivingCost';

const contextTypes = {
  router: PropTypes.object.isRequired
};

class Filter extends Component {
  constructor(props) {
    super(props);
    this.state = {
      date: '',
      cost: '',
      activeComponent: '',
    };

    this.handleFocus = this.handleFocus.bind(this);
    this.handleDateChange = this.handleDateChange.bind(this);
    this.handleCostChange = this.handleCostChange.bind(this);
    this.handleButtonClick = this.handleButtonClick.bind(this);
  }

  handleFocus(e) {
    this.setState({
      activeComponent: e.target.className.replace('-input--input', '')
    });
  }

  handleDateChange(e){
    this.setState({
      date: e.target.value
    });
  }

  handleCostChange(e){
    this.setState({
      cost: e.target.value
    });
  }

  handleButtonClick(e) {
    const { from, to } = this.props.location.query;
    const { cost, date } = this.state;
    this.context.router.push({
      pathname: '/results',
      query: {
        from,
        to,
        cost,
        date: date.toString(),
      }
    });
  }

  render() {
    return (
      <div className="Filter">
        <div className="Filter-input">
          <DrivingDate
            value={this.state.date}
            onChange={this.handleDateChange}
            onFocus={this.handleFocus}
            classNames={this.state.activeComponent === 'DrivingDate' ? 'active input' : 'inactive input'}
            first={true}
          />
          <DrivingCost
            value={this.state.cost}
            onChange={this.handleCostChange}
            onFocus={this.handleFocus}
            classNames={this.state.activeComponent === 'DrivingCost' ? 'active input' : 'inactive input'}
          />
          <button className="Filter-button"
                  onClick={this.handleButtonClick}>
                  FILTER RIDES
          </button>
        </div>
      </div>
    );
  }
}

Filter.contextTypes = contextTypes;

export default Filter;
