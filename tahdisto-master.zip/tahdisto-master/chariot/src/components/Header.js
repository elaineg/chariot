/*jshint esversion: 6 */
import React from 'react';
import {Link} from 'react-router'
import './Header.css';

function Header(){
    return (
      <header className="Header">
        <div className="container">
          <div className="row">
            <div className="col-sm-1 Header-logo"><Link to='home'>Charyot</Link></div>
            <div className="Header-menu">
              <Link to='home'>Home</Link>
              <Link to='myrides'>My Rides</Link>
            </div>
          </div>
        </div>
      </header>

    );
  }

export default Header;
