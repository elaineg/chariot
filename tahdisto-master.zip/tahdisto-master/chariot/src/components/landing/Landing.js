/*jshint esversion: 6 */
import React, {Component} from 'react';
import Scroll, {Link, Element, Events, animateScroll, scrollSpy} from 'react-scroll';
import './Landing.css';
import Card from '../Card';
import FacebookLogin from '../FacebookLogin';

var durationFn = function(deltaTop) {
    return deltaTop;
};

var exampleRides = [{
  "_id": "58d27ad3fb67491565f26390",
    "posted": true,
    "about": "This is an example ride.",
    "cost": "25",
    "date": "2019-03-24T00:00:00.000Z",
    "rideFrom": "kingston",
    "rideTo": "toronto",
    "userID": "10157685055815065"
},{
    "_id": "58d27af8fb67491565f26391",
    "posted": true,
    "about": "This is an example ride back to Kingston",
    "cost": "30",
    "date": "2019-03-26T00:00:00.000Z",
    "rideFrom": "toronto",
    "rideTo": "kingston",
    "userID": "10157685055815065",
    "__v": 0
}];

class Landing extends Component {
    constructor(props) {
        super(props);
    }

    componentDidMount() {

        Events.scrollEvent.register('begin', function() {
            //console.log("begin", arguments);
        });

        Events.scrollEvent.register('end', function() {
            //console.log("end", arguments);
        });

        scrollSpy.update();

    }
    scrollToTop() {
        animateScroll.scrollToTop();
    }
    handleSetActive() {
        // this.setState({navbarShown: false});
    }
    handleSetInactive() {
        // this.setState({navbarShown: true});
    }
    componentWillUnmount() {
        Events.scrollEvent.remove('begin');
        Events.scrollEvent.remove('end');
    }

    render() {
      const exCards = exampleRides.map((ride) => {
        return <Card key={ride._id}
                     id={ride._id}
                     rideTo={ride.rideTo}
                     rideFrom={ride.rideFrom}
                     date={ride.date}
                     cost={ride.cost}
                     userID={ride.userID}
                     about={ride.about}
                     button=""
                   />
      });
        return (
            <div>
                <Element name="test1" className="element">
                    <div className="element-overlay">
                      <div className="Landing-container">
                        <div className="Landing-header">
                            <h1 className="Landing-title">Welcome to Charyot</h1>
                            <p className="Landing-intro">Your student ridesharing hub.</p>
                        </div>
                        <div className="Landing-login">
                            <FacebookLogin/>
                        </div>
                        <div className="Landing-more">
                            <Link activeClass="active" className="" to="test2" spy={true} smooth={true} duration={500} onSetActive={this.handleSetActive} onSetInactive={this.handleSetInactive}>

                                <div className="Landing-more--chevron">
                                    <i className="fa fa-chevron-down" aria-hidden="true"></i>
                                </div>
                            </Link>
                        </div>
                      </div>
                    </div>
                </Element>

                <Element name="test2" className="element-Background1">
                    <div className="element-overlay">
                      <div className="Landing-container">
                        <div className="Landing-about ">
                            <h1>RIDESHARING MADE EASY.</h1>
                            <p>Gone are the days when you need to sift through a Facebook group to look for or offer a ride out of town. Simply log into Charyot through Facebook, and Charyot will look for rides listed by people in your community for you.
                            </p>
                            <div className="example-rides">
                              {exCards}
                            </div>
                        </div>
                      </div>

                    </div>
                </Element>
                <Element name="features1" className="feature-background">
                    <div className="row">
                        <div className="col-sm-6 box">
                            <img src="../images/png/005-filter.png" alt="lol" height="80"/>
                            <h4>
                                <strong>FILTER RIDES</strong>
                            </h4>
                            <p>Search and view rides within your price range by date or destination. No more endless surfing.</p>
                        </div>
                        <div className="col-sm-6 box">
                            <img src="../images/png/004-interface.png" alt="lol" height="80"/>
                            <h4>
                                <strong>DIRECT MESSAGING</strong>
                            </h4>
                            <p>Communicate directly with your driver with Facebook Messenger integration.</p>
                        </div>
                    </div>
                </Element>

                <Element name="test3" className="element-Background2">
                    <div className="element-overlay">
                        <div className="Landing-about ">
                            <h1>DRIVE THE FUTURE.</h1>
                            <p>Have total strangers pay your gas bill. Charyot makes the process of sharing your car intuitive and painless. You can make an unlimited number of listings completely free of charge, all through your Facebook account.
                            </p>

                            <div className="Landing-login">
                                <FacebookLogin/>
                            </div>

                        </div>
                    </div>
                </Element>

                <Element name="features1" className="feature-background">
                    <div className="row">
                        <div className="col-sm-4 box">
                            <img src="../images/png/003-placeholder.png" alt="lol" height="80"/>
                            <h4>
                                <strong>LOCATION BASED</strong>
                            </h4>
                            <p>Charyot filters rides by your location, making your search more efficient.</p>
                        </div>
                        <div className="col-sm-4 box">
                            <img src="../images/png/002-list.png" alt="lol" height="80"/>
                            <h4>
                                <strong>UNLIMITED LISTINGS</strong>
                            </h4>
                            <p>Make as many listings as you want, all for free.</p>
                        </div>
                        <div className="col-sm-4 box">
                            <img src="../images/png/001-teamwork.png" alt="lol" height="80"/>
                            <h4>
                                <strong>MAKE MONEY AND MEET PEOPLE</strong>
                            </h4>
                            <p>Make your long rides more exciting by driving others while making money.</p>
                        </div>
                    </div>

                    <a onClick={this.scrollToTop}>
                        <p className="glyphicon glyphicon-chevron-up up-arrow"></p>
                    </a>
                </Element>
            </div>
        );
    }
}

export default Landing;
