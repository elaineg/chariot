/*jshint esversion: 6 */
import {Dispatcher} from 'flux';

const FacebookDispatcher = new Dispatcher();

module.exports = FacebookDispatcher;
