/*jshint esversion: 6 */
import React, { Component } from 'react';
import {browserHistory, Link} from 'react-router'
// import FacebookStore from './stores/FacebookStore';
// import FacebookActions from './actions/FacebookActions';
import './Home.css';

class Home extends Component {
  constructor(props) {
    super(props);
    this.state = {
      user: this.props.user,
      accessToken: this.props.accessToken,
    }
  }

  onClickRiding() {
    browserHistory.push('riding');
  }

  onClickDriving() {
    browserHistory.push('driving');
  }

  render() {
    return (
      <div className="Home">
        <div className="Home-header">
          Hey {this.props.user.first_name}, Welcome to Charyot
        </div>
        <div className="Home-button">
          <button className="Home-riding--button home-header" onClick={this.onClickRiding} >I'M RIDING</button>
          <button className="Home-driving--button" onClick={this.onClickDriving} >I'M DRIVING</button>
        </div>
        <div className="Home-myRides">
          <Link to='/myrides' className="Home-myRides--a">
            Go To My Rides <i className="fa fa-long-arrow-right Home-myRides--icon" ></i>
          </Link>
        </div>
      </div>

    );
  }
}

export default Home;
