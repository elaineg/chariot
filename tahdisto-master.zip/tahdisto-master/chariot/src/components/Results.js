/*jshint esversion: 6 */
import React, { Component, PropTypes } from 'react';
import { Link } from 'react-router';
import Client from '../Client';
import Card from './Card';
import FacebookStore from './stores/FacebookStore';
import './Results.css';

const contextTypes = {
  router: PropTypes.object.isRequired
};

class Results extends Component {
  constructor(props) {
    super(props);
    this.state = {
      rides: [],
      ridesSaved: []
    };
    this.initializeRides = this.initializeRides.bind(this);
    this.initializeSavedRides = this.initializeSavedRides.bind(this);
    this.handleSaveDelete = this.handleSaveDelete.bind(this);
    this.filterRides = this.filterRides.bind(this);
    this.handleFilterClick = this.handleFilterClick.bind(this);
    this.initializeSavedRides();
    // this.initializeRides();

  }

  initializeRides() {
    const { from, to, cost, date } = this.props.location.query

    let savedRides = this.state.ridesSaved;
    Client.find_rides(from, to, (ridesList) => {
      let rides = ridesList.map((ride) => {
        let newRide = ride;
        newRide.saved = false;
        savedRides.find((save) => {
          if (save === ride._id){
            newRide.saved = true;
          }
        });
        return newRide;
      });
      rides.sort((a,b) => {
        return new Date(a.date) - new Date(b.date);
      });
      if (cost || date) {
        rides = this.filterRides(rides);
      }
      this.setState({
        rides: rides
      });
    });
  }

  initializeSavedRides(){
    Client.find_user(FacebookStore.userId, (user) => {
      // var savedRides = [];
      const userSavedRides = user[0].savedRides;
      if(userSavedRides.length > 0){
        let savedRides = userSavedRides.map(function(ride){
          return ride;
        });
        this.setState({
          ridesSaved: savedRides
        });
      }
      this.initializeRides();
    });
  }
  handleSaveDelete(id){
    var rides = this.state.rides;
    var saved = this.state.ridesSaved;
    rides.find(function(ride, index){
      if(ride._id === id){
        if(ride.saved){
          Client.remove_saved(FacebookStore.userId, ride._id, (response) => {
            console.log(response);
          });
          rides[index].saved = false;
          saved.find(function(ride, index) {
            if(ride === id){
              delete saved[index];
            }
          });
        } else {
          Client.add_saved(FacebookStore.userId, ride._id, (response) => {
            console.log(response);
          });
          rides[index].saved = true;
          saved.push(ride._id);
        }
      }
    });

    this.setState({
      rides: rides,
      ridesSaved: saved
    });
  }

  filterRides(rides) {
    const { cost, date } = this.props.location.query
    let ridesList = rides;
    if (date) {
      ridesList = rides.filter((ride) => {
        // strip timezone
        const rideDate = ride.date.toString().substr(0, 10);
        console.log(date);
        console.log(rideDate);
        return rideDate === date;
      });
    }
    if (cost) {
      ridesList = ridesList.filter(ride => cost >= ride.cost);
    }

    return ridesList;
  }

  handleFilterClick(e) {
    const { from, to } = this.props.location.query;
    this.context.router.push({
      pathname: '/results/filter',
      query: {
        from,
        to,
      }
    });
  }

  render() {
    const rides = this.state.rides.map((ride) => {
      return <Card key={ride._id}
                   id={ride._id}
                   rideTo={ride.rideTo}
                   rideFrom={ride.rideFrom}
                   date={ride.date}
                   cost={ride.cost}
                   about={ride.about}
                   userID={ride.userID}
                   posted={ride.posted}
                   saved={ride.saved}
                   handleSaveDelete={this.handleSaveDelete}
                   button="Message" />
    });
    return (
      <div className="Results-container">
        <div className="Results-title-container">
          <h2 className="Results-title">Results</h2>
        </div>
        <div className="Results-filter">
          <div className="Results-filter-link" to="/results/filter" onClick={this.handleFilterClick}>
            <i className="fa fa-filter Results-filter-icon" aria-hidden="true"></i>
          </div>
        </div>
        {rides}
      </div>
    )
  }
}

Results.contextTypes = contextTypes;

export default Results;
