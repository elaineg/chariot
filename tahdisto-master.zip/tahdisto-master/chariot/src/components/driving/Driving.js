/*jshint esversion: 6 */
import React, { Component } from 'react';
import './Driving.css';
import DrivingFrom from './DrivingFrom';
import DrivingTo from './DrivingTo';
import DrivingCost from './DrivingCost';
import DrivingAbout from './DrivingAbout';
import DrivingDate from './DrivingDate';
import Card from '../Card';
import {browserHistory} from 'react-router';
import Client from '../../Client';



class Driving extends Component {
  constructor(props) {
    super(props);
    this.state = {
      DrivingTo: '',
      DrivingFrom: '',
      DrivingDate: '',
      DrivingCost: '',
      DrivingAbout: '',
      activeComponent: '',
      showConfirm: false
    };
    this.handleFromChange = this.handleFromChange.bind(this);
    this.handleToChange = this.handleToChange.bind(this);
    this.handleDateChange = this.handleDateChange.bind(this);
    this.handleCostChange = this.handleCostChange.bind(this);
    this.handleAboutChange = this.handleAboutChange.bind(this);
    this.handleConfirmClick = this.handleConfirmClick.bind(this);
    this.handleSubmitClick = this.handleSubmitClick.bind(this);
    this.handleFocus = this.handleFocus.bind(this);


  }

  handleFromChange(e){
    this.setState({
      DrivingFrom: e.target.value
    });
  }

  handleToChange(e){
    this.setState({
      DrivingTo: e.target.value
    });
  }

  handleDateChange(e){
    this.setState({
      DrivingDate: e.target.value
    });
  }

  handleCostChange(e){
    this.setState({
      DrivingCost: e.target.value
    });
  }

  handleAboutChange(e){
    this.setState({
      DrivingAbout: e.target.value
    });
  }

  handleConfirmClick() {
    this.setState({
      showConfirm: true
    });
  }

  handleFocus(e) {
    this.setState({
      activeComponent: e.target.className.replace('-input--input', '')
    });
  }

  handleSubmitClick() {
    var ridingFrom = this.state.DrivingFrom.toLowerCase();
    var ridingTo = this.state.DrivingTo.toLowerCase();
    const newRide = {
      userID: this.props.user.id,
      rideTo: ridingTo.trim(),
      rideFrom: ridingFrom.trim(),
      date: this.state.DrivingDate.toString(),
      cost: this.state.DrivingCost,
      about: this.state.DrivingAbout,
      posted: true
    };

    Client.add_ride(newRide, (addedRide) => {
      if(addedRide.message === "Ride created!"){
        console.log(addedRide.message);
        browserHistory.push('home');
      }
    });
  }

  render() {
    return (
      <div className="Driving">
        <div className="Driving-input">
          <DrivingFrom
            value={this.state.DrivingFrom}
            onChange={this.handleFromChange}
            onFocus={this.handleFocus}
            classNames={this.state.activeComponent === 'DrivingFrom' ? 'active input' : 'inactive input'}
          />
          <DrivingTo
            value={this.state.DrivingTo}
            onChange={this.handleToChange}
            onFocus={this.handleFocus}
            classNames={this.state.activeComponent === 'DrivingTo' ? 'active input' : 'inactive input'}
          />
          <DrivingDate
            value={this.state.DrivingDate}
            onChange={this.handleDateChange}
            onFocus={this.handleFocus}
            classNames={this.state.activeComponent === 'DrivingDate' ? 'active input' : 'inactive input'}
            first={false}
          />
          <DrivingCost
            value={this.state.DrivingCost}
            onChange={this.handleCostChange}
            onFocus={this.handleFocus}
            classNames={this.state.activeComponent === 'DrivingCost' ? 'active input' : 'inactive input'}
          />
          <DrivingAbout
            value={this.state.DrivingAbout}
            onChange={this.handleAboutChange}
            onFocus={this.handleFocus}
            classNames={this.state.activeComponent === 'DrivingAbout' ? 'active input' : 'inactive input'}
            handleConfirmClick={this.handleConfirmClick}
            showConfirm={this.state.showConfirm}
            activeComponent={this.state.activeComponent}
          />
          {
            this.state.showConfirm ? (
              <div className="Driving-confirm--container">
                <Card
                  rideTo={this.state.DrivingTo}
                  rideFrom={this.state.DrivingFrom}
                  date={this.state.DrivingDate}
                  cost={this.state.DrivingCost}
                  about={this.state.DrivingAbout}
                  userID={this.props.user.id}
                  button="Confirm"
                  onClick={this.handleSubmitClick}
                  expanded={true}
                />
              </div>
            ) : ''
          }





        </div>
      </div>

    );
  }
}

export default Driving;
