/*jshint esversion: 6 */
import React, { Component } from 'react';
import './DrivingFrom.css';

class DrivingFrom extends Component {
  constructor(props) {
    super(props);
    // this.state = {
    //   // from: '',
    //   showNext: true
    // };
    this.handleSearchFromChange = this.handleSearchFromChange.bind(this);

  }

  handleSearchFromChange(e) {
    if(this.props.onChange){
      this.props.onChange(e);
    }
    // if (this.props.value === '') {
    //   this.setState({
    //     showNext: false
    //   });
    // } else {
    //   this.setState({
    //     showNext: true
    //   });
    // }
  }

  render() {
    return (
      <div className={`DrivingFrom ${ this.props.classNames }`}>
        <h1 className="DrivingFrom-title">Where are you coming from?</h1>
        <div className="DrivingFrom-input">
          <input
              className='DrivingFrom-input--input'
              type='text'
              value={this.props.value}
              onChange={this.handleSearchFromChange}
              onFocus={this.props.onFocus}
              autoFocus
          />
        </div>
      </div>

    );
  }
}

export default DrivingFrom;
