/*jshint esversion: 6 */
import React, { Component } from 'react';
import './DrivingCost.css';

class DrivingCost extends Component {
  constructor(props) {
    super(props);
    // this.state = {
    //   // from: '',
    //   showNext: true
    // };
    this.handleSearchFromChange = this.handleSearchFromChange.bind(this);

  }

  handleSearchFromChange(e) {
    if(this.props.onChange){
      this.props.onChange(e);
    }
    // if (this.props.value === '') {
    //   this.setState({
    //     showNext: false
    //   });
    // } else {
    //   this.setState({
    //     showNext: true
    //   });
    // }
  }

  render() {
    return (
      <div className={`DrivingCost ${ this.props.classNames }`}>
        <h1 className="DrivingCost-title">Approximate price?</h1>
        <div className="DrivingCost-input">
          $<input
              className='DrivingCost-input--input'
              type='text'
              value={this.props.value}
              onChange={this.handleSearchFromChange}
              onFocus={this.props.onFocus}
          />
        </div>
      </div>

    );
  }
}

export default DrivingCost;
