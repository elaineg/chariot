/*jshint esversion: 6 */
import React, { Component } from 'react';
import './DrivingDate.css';

class DrivingDate extends Component {
  constructor(props) {
    super(props);
    // this.state = {
    //   // from: '',
    //   showNext: true
    // };
    this.handleSearchFromChange = this.handleSearchFromChange.bind(this);

  }

  handleSearchFromChange(e) {
    if(this.props.onChange){
      this.props.onChange(e);
    }
    // if (this.props.value === '') {
    //   this.setState({
    //     showNext: false
    //   });
    // } else {
    //   this.setState({
    //     showNext: true
    //   });
    // }
  }

  render() {
    return (
      <div className={`DrivingDate ${ this.props.classNames }`}>
        <h1 className="DrivingDate-title">When will you be going?</h1>
        <div className="DrivingDate-input">
          {this.props.first ?
            <input
                className='DrivingDate-input--input'
                type='date'
                value={this.props.value}
                onChange={this.handleSearchFromChange}
                onFocus={this.props.onFocus}
                autoFocus
            /> :
            <input
                className='DrivingDate-input--input'
                type='date'
                value={this.props.value}
                onChange={this.handleSearchFromChange}
                onFocus={this.props.onFocus}
            />
          }

        </div>
      </div>

    );
  }
}

export default DrivingDate;
