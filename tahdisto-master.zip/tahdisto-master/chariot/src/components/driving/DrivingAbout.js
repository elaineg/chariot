/*jshint esversion: 6 */
import React, { Component } from 'react';
import './DrivingAbout.css';

class DrivingAbout extends Component {
  constructor(props) {
    super(props);
    // this.state = {
    //   // from: '',
    //   showNext: true
    // };
    this.handleSearchFromChange = this.handleSearchFromChange.bind(this);

  }

  handleSearchFromChange(e) {
    if(this.props.onChange){
      this.props.onChange(e);
    }
    // if (this.props.value === '') {
    //   this.setState({
    //     showNext: false
    //   });
    // } else {
    //   this.setState({
    //     showNext: true
    //   });
    // }
  }

  render() {
    return (
      <div className={`DrivingAbout ${ this.props.classNames }`}>
        <h1 className="DrivingAbout-title">Any other details you would like to share?</h1>
        <div className="DrivingAbout-input">
          <textarea
            className="DrivingAbout-input--input"
            value={this.props.value}
            onChange={this.handleSearchFromChange}
            onFocus={this.props.onFocus}
            rows="3"
          />
        </div>
        {!this.props.showConfirm ? (
          <button className="Driving-create--button"
                  onClick={this.props.handleConfirmClick}
                  disabled={this.props.activeComponent !== 'DrivingAbout'}>
                  CREATE RIDE
          </button>
          ) : ''
        }
      </div>

    );
  }
}

export default DrivingAbout;
