/*jshint esversion: 6 */
import React, { Component } from 'react';
import './DrivingTo.css';

class DrivingTo extends Component {
  constructor(props) {
    super(props);
    // this.state = {
    //   showSearchButton: true
    // };
    this.handleSearchGoingChange = this.handleSearchGoingChange.bind(this);

  }

  handleSearchGoingChange(e) {
    if(this.props.onChange){
      this.props.onChange(e);
    }

    // if (this.props.value === '') {
    //   this.setState({
    //     showSearchButton: false
    //   });
    // } else {
    //   this.setState({
    //     showSearchButton: true
    //   });
    // }
  }

  render() {
    return (
      <div className={`DrivingTo ${ this.props.classNames }`}>
        <h1 className="DrivingTo-title">Where are you going?</h1>
          <div className="DrivingFrom-input">
            <input
                className='DrivingTo-input--input'
                type='text'
                value={this.props.value}
                onChange={this.handleSearchGoingChange}
                onFocus={this.props.onFocus}
            />
          </div>
      </div>

    );
  }
}

export default DrivingTo;
