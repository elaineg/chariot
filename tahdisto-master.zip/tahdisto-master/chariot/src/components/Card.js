/*jshint esversion: 6 */
import React, { Component, PropTypes} from 'react';
import moment from 'moment';
import Client from '../Client';
import FacebookStore from './stores/FacebookStore';
import {Link} from 'react-router';
import './Card.css';

const propTypes = {
  rideFrom: PropTypes.string,
  rideTo: PropTypes.string,
  date: PropTypes.string,
  cost: PropTypes.string,
  user: PropTypes.object,
  button: PropTypes.string,
  expanded: PropTypes.bool,
  onClick: PropTypes.func,
};

const defaultProps = {
  expanded: false
};

class Card extends Component {
  constructor(props) {
    super(props);
    this.state = {
      user: {},
      expanded: this.props.expanded
    };
    this.handleDetailsClick = this.handleDetailsClick.bind(this);
    this.handleMessageClick = this.handleMessageClick.bind(this);
  }

  componentDidMount(){
    window.FB.api(`/${this.props.userID}`, {
        fields: 'first_name,link'
    }, (response) => {
      this.setState({
        user: response
      });
    });
  }
  handleDetailsClick() {
    const newState = !this.state.expanded;
    this.setState({
      expanded: newState
    });
  }

  handleMessageClick() {
    // Analytics -- save that they messaged this specific user!!!!!!!
  }

  render() {
    // strip timezone
    const date = this.props.date.substr(0, 10);
    if (!this.state.expanded) {
      return (
        <article className="Card">
          <div className="body clearfix">
            <div className="row">
              <div className="col-md-2">
                <div className="profile-img">
                  <img alt="profile-pic" className="img-circle" src={"https://graph.facebook.com/" + this.props.userID + "/picture?type=large"} />
                  <div className="name-label-container">
                    <span className="label label-default name-label">{this.state.user.first_name}</span>
                  </div>
                </div>
              </div>
              <div className="col-md-8">

                <div className="ride-info">
                  <p className="cities">
                    <span className="city-names">{this.props.rideFrom} </span>
                    to
                    <span className="city-names"> {this.props.rideTo}</span>
                  </p>
                  <p className="date">
                    <i className="fa fa-calendar" aria-hidden="true"></i>
                    <span className="date-text">{moment(date).format('MMMM Do YYYY')}</span>
                  </p>
                  <p className="cost">Cost <span className="cost-amount">${this.props.cost}</span></p>
                </div>
              </div>
              <div className="col-md-2">
                <button className="btn details-btn" onClick={this.handleDetailsClick}>Details</button>
                  {(this.props.button === "Delete" && this.props.posted) ?
                    (
                      <a onClick={() => this.props.handleDeleteRide(this.props.id)}><i className="fa fa-trash-o" aria-hidden="true"></i></a>
                    ) : null
                  }
                  {(this.props.button === "Message" && this.props.posted) ?
                      <a onClick={() => this.props.handleSaveDelete(this.props.id)}><i className={this.props.saved ? "fa fa-trash-o" : "fa fa-floppy-o"} aria-hidden="true"></i></a>
                     : null
                  }
              </div>
            </div>
          </div>
        </article>
      )
    }
    else {
      return (
        <article className="Card">
          <div className="body clearfix body--active">
            <div className="row">
              <div className="col-xs-2">
                <div className="profile-img">
                  <img alt="profile-pic" className="img-circle" src={"https://graph.facebook.com/" + this.props.userID + "/picture?type=large"} />
                  <div className="name-label-container">
                    <span className="label label-default name-label">{this.state.user.first_name}</span>
                  </div>
                </div>
              </div>
              <div className="col-xs-8">
                <div className="ride-info">
                  <p className="cities">
                    <span className="city-names">{this.props.rideFrom} </span>
                    to
                    <span className="city-names"> {this.props.rideTo}</span>
                  </p>
                  <p className="date"><i className="fa fa-calendar" aria-hidden="true"></i><span className="date-text">{moment(date).format('MMMM Do YYYY')}</span></p>
                  <p className="cost">Cost <span className="cost-amount">${this.props.cost}</span></p>
                </div>
              </div>
              <div className="col-xs-2">
                <button className="btn details-btn" onClick={this.handleDetailsClick}>Details</button>
                  {(this.props.button === "Delete" && this.props.posted) ?
                    (
                      <a onClick={() => this.props.handleDeleteRide(this.props.id)}><i className="fa fa-trash-o" aria-hidden="true"></i></a>
                    ) : null
                  }
                  {(this.props.button === "Message" && this.props.posted) ?
                      <a onClick={() => this.props.handleSaveDelete(this.props.id)}><i  className={this.props.saved ? "fa fa-trash-o" : "fa fa-floppy-o"} aria-hidden="true"></i></a>
                     : null
                  }
              </div>
            </div>
          </div>
          <div className="description">
            <p className="description-text">{this.props.about}</p>
              {(this.props.button === "Message" && this.props.posted) ?
                (
                  <Link to={this.state.user.link}
                      target="_blank"
                      onClick={this.handleMessageClick}
                      className="btn message-btn">
                      {this.props.button} {this.state.user.first_name}
                    </Link>
                ) : <br/>
              }
              {(this.props.button === "Confirm") ?
                (
                  <a onClick={this.props.onClick} className="btn message-btn">{this.props.button}</a>
                ) : <br/>
              }
        </div>
        </article>
      )
    }
  }
}

Card.propTypes = propTypes;
Card.defaultProps = defaultProps;

export default Card;
