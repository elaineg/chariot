/*jshint esversion: 6 */
import React, { Component } from 'react';
import FacebookActions from './actions/FacebookActions';
import './FacebookLogin.css';
// <button className="Facebook-login-btn" onClick={this.fbLogin}>LOGIN WITH FACEBOOK</button>

class FacebookLogin extends Component {

    render() {
        return (
              <div className="btn-group">
    		          <a className='btn btn-primary FB-login-btn' onClick={this.fbLogin}><i className="fa fa-facebook"></i> | Sign in with Facebook</a>
    	        </div>
        );
    }

    fbLogin(e) {
        FacebookActions.login();
    }
}

export default FacebookLogin;
